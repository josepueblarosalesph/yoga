<?php

use Livewire\Component;
use App\Models\Hora;
use App\Models\Reserva;
use Illuminate\Support\Facades\Auth;

return new class extends Component
{
    public $horas;
    public $idseleccionado = "lala1";
    public $reservas;
    public bool $myModal1 = false;


    public function mount()
    {
        $this->horas = Hora::all();
        $this->reservas = Reserva::all();
    }

    public function mensaje($horaid)
    {
        if (Reserva::where('user_id', Auth::id())->where('hora_id', $horaid)->get()->count() == 0) {
            $reserva = new Reserva;
            $reserva->user_id = Auth::id();
            $reserva->hora_id = $horaid;
            $reserva->save();
            $this->reservas = Reserva::all();
        } else {
            $this->myModal1 = true;
        }
    }
    public function sacar($horaid)
    {
        Reserva::where('user_id', Auth::id())->where('hora_id', $horaid)->delete();
    }
    public function expulsar($horaid, $userid)
    {
        Reserva::where('user_id', $userid)->where('hora_id', $horaid)->delete();
    }

    protected function view($data = [])
    {
        return app('view')->file('/Users/josepuebla/Herd/Yoga/storage/framework/views/livewire/views/3a37740b.blade.php', $data);
    }
};
