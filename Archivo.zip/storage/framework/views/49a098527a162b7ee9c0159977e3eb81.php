

<tbody <?php echo e($attributes); ?> data-flux-rows>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH /Users/josepuebla/Herd/Yoga/vendor/livewire/flux/src/../stubs/resources/views/flux/table/rows.blade.php ENDPATH**/ ?>